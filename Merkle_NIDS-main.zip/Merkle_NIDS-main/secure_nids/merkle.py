import hashlib

def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()

def hash_leaf(data: bytes) -> bytes:
    return sha256(b"\\x00" + data)

def hash_node(left: bytes, right: bytes) -> bytes:
    return sha256(b"\\x01" + left + right)

def root_from_hashes(hashes):
    if not hashes:
        return sha256(b"")
    level = list(hashes)
    while len(level) > 1:
        if len(level) % 2:
            level.append(level[-1])
        level = [hash_node(level[i], level[i+1]) for i in range(0, len(level), 2)]
    return level[0]

def root_hex(leaf_hashes_hex):
    return root_from_hashes([bytes.fromhex(x) for x in leaf_hashes_hex]).hex()


def inclusion_proof(leaf_hashes_hex, index):
    if not 0 <= index < len(leaf_hashes_hex):
        raise IndexError("leaf index outside tree")
    level = [bytes.fromhex(value) for value in leaf_hashes_hex]
    proof = []
    while len(level) > 1:
        if len(level) % 2:
            level.append(level[-1])
        sibling = index ^ 1
        proof.append({"hash": level[sibling].hex(), "side": "left" if sibling < index else "right"})
        level = [hash_node(level[i], level[i + 1]) for i in range(0, len(level), 2)]
        index //= 2
    return proof


def verify_inclusion(leaf_hash_hex, proof, expected_root_hex):
    current = bytes.fromhex(leaf_hash_hex)
    for step in proof:
        sibling = bytes.fromhex(step["hash"])
        if step["side"] == "left":
            current = hash_node(sibling, current)
        elif step["side"] == "right":
            current = hash_node(current, sibling)
        else:
            return False
    return current.hex() == expected_root_hex
