from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from .runtime import Runtime

runtime = None

@asynccontextmanager
async def lifespan(app):
    global runtime
    runtime = Runtime()
    yield

app = FastAPI(title="Secure Merkle NIDS", lifespan=lifespan)

class ManualAlert(BaseModel):
    src_ip: str = "127.0.0.1"
    dst_ip: str = "127.0.0.1"
    src_port: int = 12345
    dst_port: int = 443
    protocol: str = "TCP"
    label: str = "TEST_ATTACK"
    confidence: float = 0.99
    severity: str = "high"

@app.get("/health")
def health():
    return {"ok": True, "model_loaded": runtime.detector.model is not None}

@app.post("/alerts/manual")
def manual_alert(a: ManualAlert):
    return runtime.store.add_alert(a.model_dump())

@app.get("/integrity/verify")
def verify():
    return runtime.store.verify_integrity()

@app.post("/integrity/checkpoint")
def checkpoint():
    runtime.store.create_checkpoint()
    return {"ok": True}

@app.post("/capture/start")
def start(iface: str | None = None):
    try:
        runtime.capture.start_live(iface)
        return {"ok": True}
    except Exception as e:
        raise HTTPException(400, str(e))

@app.post("/capture/stop")
def stop():
    runtime.capture.stop_live()
    return {"ok": True}
