"""Features shared by live inference and CICIDS2017 training."""

MODEL_FEATURES = [
    "flow_duration",
    "total_fwd_packets",
    "total_bwd_packets",
    "syn_flag_count",
    "ack_flag_count",
    "rst_flag_count",
    "psh_flag_count",
    "fin_flag_count",
]

CIC_COLUMNS = {
    "flow_duration": "Flow Duration",
    "total_fwd_packets": "Total Fwd Packets",
    "total_bwd_packets": "Total Backward Packets",
    "syn_flag_count": "SYN Flag Count",
    "ack_flag_count": "ACK Flag Count",
    "rst_flag_count": "RST Flag Count",
    "psh_flag_count": "PSH Flag Count",
    "fin_flag_count": "FIN Flag Count",
}
