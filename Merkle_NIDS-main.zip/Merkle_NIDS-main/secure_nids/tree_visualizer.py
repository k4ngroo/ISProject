"""Write a standalone, clickable view of one Merkle checkpoint."""
import json
from pathlib import Path

from .merkle import hash_node, sha256


def write_tree(path, leaf_hashes, checkpoint_id, expected_root):
    level = [{"hash": value, "duplicate": False, "x": 80 + index * 160}
             for index, value in enumerate(leaf_hashes)]
    if not level:
        level = [{"hash": sha256(b"").hex(), "duplicate": False, "x": 80}]
    levels = [level]
    while len(level) > 1:
        current = [dict(node) for node in level]
        if len(current) % 2:
            copy = dict(current[-1])
            copy["duplicate"] = True
            copy["x"] += 160 * (2 ** (len(levels) - 1))
            current.append(copy)
        levels[-1] = current
        level = [{"hash": hash_node(bytes.fromhex(current[i]["hash"]),
                                    bytes.fromhex(current[i + 1]["hash"])).hex(),
                  "duplicate": False, "x": (current[i]["x"] + current[i + 1]["x"]) / 2}
                 for i in range(0, len(current), 2)]
        levels.append(level)
    if levels[-1][0]["hash"] != expected_root:
        raise ValueError("visualization root does not match checkpoint")
    width = max(760, int(max(node["x"] for row in levels for node in row) + 100))
    height = len(levels) * 100 + 40
    data = json.dumps(levels)
    html = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Merkle checkpoint {checkpoint_id}</title>
<style>
body {{ font: 15px system-ui, sans-serif; margin: 24px; background: #0f172a; color: #e2e8f0; }}
h1 {{ font-size: 22px; }} code {{ overflow-wrap: anywhere; color: #93c5fd; }}
.scroll {{ overflow: auto; border: 1px solid #475569; border-radius: 10px; background: #111c32; }}
svg {{ display: block; }} line {{ stroke: #64748b; stroke-width: 2; }}
circle {{ fill: #2563eb; stroke: #bfdbfe; stroke-width: 2; }}
g.duplicate circle {{ fill: #7c3aed; }} g.path circle {{ fill: #16a34a; }}
g.sibling circle {{ fill: #d97706; }} g.leaf {{ cursor: pointer; }}
text {{ fill: white; font: 14px system-ui, sans-serif; text-anchor: middle; pointer-events: none; }}
#details {{ white-space: pre-wrap; line-height: 1.5; margin-top: 18px; }}
</style></head><body>
<h1>Merkle checkpoint {checkpoint_id}</h1>
<p>{len(leaf_hashes)} alerts · signed root: <code>{expected_root}</code></p>
<p>Click an alert leaf to highlight its path (green) and sibling hashes (orange). Purple nodes are duplicated to complete an odd level.</p>
<div class="scroll"><svg id="tree" viewBox="0 0 {width} {height}" width="{width}" height="{height}" role="img" aria-label="Merkle tree for checkpoint {checkpoint_id}"></svg></div>
<div id="details">Select a leaf to show its proof path.</div>
<script>
const levels = {data};
const svg = document.getElementById('tree');
const ns = 'http://www.w3.org/2000/svg';
function element(name, attributes, parent) {{
  const item = document.createElementNS(ns, name);
  for (const [key, value] of Object.entries(attributes)) item.setAttribute(key, value);
  parent.appendChild(item); return item;
}}
function y(level) {{ return {height} - 70 - level * 100; }}
for (let level = 1; level < levels.length; level++) {{
  levels[level - 1].forEach((node, index) => {{
    element('line', {{x1: node.x, y1: y(level - 1), x2: levels[level][Math.floor(index / 2)].x, y2: y(level)}}, svg);
  }});
}}
levels.forEach((row, level) => row.forEach((node, index) => {{
  const group = element('g', {{id: `node-${{level}}-${{index}}`, class: `${{node.duplicate ? 'duplicate ' : ''}}${{level === 0 && index < {len(leaf_hashes)} ? 'leaf' : ''}}`}}, svg);
  element('circle', {{cx: node.x, cy: y(level), r: 29}}, group);
  const label = element('text', {{x: node.x, y: y(level) + 5}}, group);
  label.textContent = level === levels.length - 1 ? 'ROOT' : level === 0 ? `L${{index + 1}}${{node.duplicate ? '*' : ''}}` : `H${{level}}`;
  const title = element('title', {{}}, group); title.textContent = node.hash;
  if (level === 0 && index < {len(leaf_hashes)}) group.addEventListener('click', () => select(index));
}}));
function select(leaf) {{
  document.querySelectorAll('g.path, g.sibling').forEach(node => node.classList.remove('path', 'sibling'));
  let index = leaf; const siblings = [];
  for (let level = 0; level < levels.length; level++) {{
    document.getElementById(`node-${{level}}-${{index}}`).classList.add('path');
    if (level < levels.length - 1) {{
      const sibling = index ^ 1;
      document.getElementById(`node-${{level}}-${{sibling}}`).classList.add('sibling');
      siblings.push(`${{level + 1}}. ${{sibling < index ? 'left' : 'right'}}: ${{levels[level][sibling].hash}}`);
      index = Math.floor(index / 2);
    }}
  }}
  document.getElementById('details').textContent = `Alert ${{leaf + 1}} leaf: ${{levels[0][leaf].hash}}\nSibling path:\n${{siblings.join(String.fromCharCode(10))}}\nRoot: {expected_root}`;
}}
</script></body></html>"""
    Path(path).write_text(html, encoding="utf-8")
