"""Secure Merkle NIDS."""
__version__ = "0.1.0"
