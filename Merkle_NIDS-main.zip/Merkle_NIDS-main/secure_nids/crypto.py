import json, os
from pathlib import Path
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

def canonical_json(data):
    return json.dumps(data, sort_keys=True, separators=(",", ":")).encode()

class KeyManager:
    def __init__(self, key_dir):
        self.key_dir = Path(key_dir)
        self.key_dir.mkdir(parents=True, exist_ok=True)
        self.private_path = self.key_dir / "rsa_private.pem"
        self.public_path = self.key_dir / "rsa_public.pem"
        self.aes_path = self.key_dir / "aes256.key.enc"
        self._ensure()
        self.private = serialization.load_pem_private_key(self.private_path.read_bytes(), password=None)
        self.public = self.private.public_key()
        self.aes_key = self.private.decrypt(
            self.aes_path.read_bytes(),
            padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
        )

    def _ensure(self):
        if not self.private_path.exists():
            priv = rsa.generate_private_key(public_exponent=65537, key_size=3072)
            self.private_path.write_bytes(priv.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption()
            ))
            self.public_path.write_bytes(priv.public_key().public_bytes(
                serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo
            ))
        if not self.aes_path.exists():
            public = serialization.load_pem_public_key(self.public_path.read_bytes())
            aes = AESGCM.generate_key(bit_length=256)
            wrapped = public.encrypt(
                aes,
                padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
            )
            self.aes_path.write_bytes(wrapped)

    def encrypt(self, plaintext: bytes, aad: bytes):
        nonce = os.urandom(12)
        ct = AESGCM(self.aes_key).encrypt(nonce, plaintext, aad)
        return nonce, ct

    def decrypt(self, nonce, ciphertext, aad):
        return AESGCM(self.aes_key).decrypt(nonce, ciphertext, aad)

    def sign(self, message: bytes):
        return self.private.sign(
            message,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.DIGEST_LENGTH),
            hashes.SHA256()
        )

    def verify(self, message: bytes, signature: bytes):
        try:
            self.public.verify(
                signature, message,
                padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.DIGEST_LENGTH),
                hashes.SHA256()
            )
            return True
        except InvalidSignature:
            return False
