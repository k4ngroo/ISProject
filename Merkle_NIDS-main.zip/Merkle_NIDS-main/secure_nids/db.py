import base64, json, sqlite3, uuid
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from .crypto import canonical_json
from .merkle import hash_leaf, root_hex, inclusion_proof, verify_inclusion
from .tree_visualizer import write_tree

class ForensicStore:
    def __init__(self, db_path, crypto, anchor_dir, checkpoint_interval=100):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.crypto = crypto
        self.anchor_dir = Path(anchor_dir)
        self.anchor_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_interval = max(1, checkpoint_interval)
        self._init()

    def connect(self):
        con = sqlite3.connect(self.db_path)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL")
        return con

    def _init(self):
        with closing(self.connect()) as con, con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS alerts(
                seq INTEGER PRIMARY KEY,
                alert_id TEXT UNIQUE NOT NULL,
                created_at TEXT NOT NULL,
                src_ip TEXT,
                dst_ip TEXT,
                src_port INTEGER,
                dst_port INTEGER,
                protocol TEXT,
                label TEXT,
                confidence REAL,
                severity TEXT,
                nonce BLOB NOT NULL,
                ciphertext BLOB NOT NULL,
                leaf_hash TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS checkpoints(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                record_count INTEGER NOT NULL,
                root_hash TEXT NOT NULL,
                previous_root TEXT,
                signature BLOB NOT NULL
            );
            """)

    def _leaf_material(self, row):
        return canonical_json({
            "seq": row["seq"],
            "alert_id": row["alert_id"],
            "created_at": row["created_at"],
            "src_ip": row.get("src_ip"),
            "dst_ip": row.get("dst_ip"),
            "src_port": row.get("src_port"),
            "dst_port": row.get("dst_port"),
            "protocol": row.get("protocol"),
            "label": row.get("label"),
            "confidence": float(row.get("confidence", 0)),
            "severity": row.get("severity"),
            "nonce": base64.b64encode(row["nonce"]).decode(),
            "ciphertext": base64.b64encode(row["ciphertext"]).decode(),
        })

    def add_alert(self, payload):
        created_at = payload.get("created_at") or datetime.now(timezone.utc).isoformat()
        alert_id = payload.get("alert_id") or str(uuid.uuid4())
        with closing(self.connect()) as con, con:
            seq = con.execute("SELECT COALESCE(MAX(seq),0)+1 FROM alerts").fetchone()[0]
            aad = f"{seq}|{alert_id}|{created_at}".encode()
            nonce, ciphertext = self.crypto.encrypt(canonical_json(payload), aad)

            row = {
                "seq": seq, "alert_id": alert_id, "created_at": created_at,
                "src_ip": payload.get("src_ip"), "dst_ip": payload.get("dst_ip"),
                "src_port": payload.get("src_port"), "dst_port": payload.get("dst_port"),
                "protocol": payload.get("protocol"), "label": payload.get("label", "UNKNOWN"),
                "confidence": float(payload.get("confidence", 0)),
                "severity": payload.get("severity", "medium"),
                "nonce": nonce, "ciphertext": ciphertext
            }
            leaf = hash_leaf(self._leaf_material(row)).hex()
            con.execute("""
                INSERT INTO alerts VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                seq, alert_id, created_at, row["src_ip"], row["dst_ip"],
                row["src_port"], row["dst_port"], row["protocol"], row["label"],
                row["confidence"], row["severity"], nonce, ciphertext, leaf
            ))
            if seq % self.checkpoint_interval == 0:
                self._checkpoint(con)
        return {"seq": seq, "alert_id": alert_id, "leaf_hash": leaf}

    def _checkpoint(self, con):
        hashes = [r[0] for r in con.execute("SELECT leaf_hash FROM alerts ORDER BY seq")]
        root = root_hex(hashes)
        prev = con.execute("SELECT root_hash FROM checkpoints ORDER BY id DESC LIMIT 1").fetchone()
        prev_root = prev[0] if prev else None
        message = canonical_json({"root_hash": root, "record_count": len(hashes), "previous_root": prev_root})
        sig = self.crypto.sign(message)
        cur = con.execute(
            "INSERT INTO checkpoints(record_count, root_hash, previous_root, signature) VALUES(?,?,?,?)",
            (len(hashes), root, prev_root, sig)
        )
        anchor = {
            "checkpoint_id": cur.lastrowid,
            "record_count": len(hashes),
            "root_hash": root,
            "previous_root": prev_root,
            "signature_b64": base64.b64encode(sig).decode()
        }
        (self.anchor_dir / f"checkpoint_{cur.lastrowid:08d}.json").write_text(json.dumps(anchor, indent=2))
        write_tree(self.anchor_dir / f"checkpoint_{cur.lastrowid:08d}.html", hashes, cur.lastrowid, root)
        write_tree(self.anchor_dir / "merkle_tree_latest.html", hashes, cur.lastrowid, root)

    def create_checkpoint(self):
        with closing(self.connect()) as con, con:
            self._checkpoint(con)

    def record_proof(self, seq, checkpoint_id=None):
        with closing(self.connect()) as con, con:
            if checkpoint_id is None:
                cp = con.execute("SELECT * FROM checkpoints WHERE record_count >= ? ORDER BY id DESC LIMIT 1", (seq,)).fetchone()
            else:
                cp = con.execute("SELECT * FROM checkpoints WHERE id=? AND record_count >= ?", (checkpoint_id, seq)).fetchone()
            if cp is None:
                raise ValueError("no checkpoint covers this record")
            rows = con.execute("SELECT seq, leaf_hash FROM alerts WHERE seq <= ? ORDER BY seq", (cp["record_count"],)).fetchall()
        if len(rows) != cp["record_count"] or [r["seq"] for r in rows] != list(range(1, len(rows) + 1)):
            raise ValueError("checkpoint records are missing or reordered")
        leaves = [r["leaf_hash"] for r in rows]
        return {"seq": seq, "checkpoint_id": cp["id"], "root_hash": cp["root_hash"],
                "leaf_hash": leaves[seq - 1], "siblings": inclusion_proof(leaves, seq - 1)}

    def verify_record_proof(self, proof):
        with closing(self.connect()) as con, con:
            row = con.execute("SELECT * FROM alerts WHERE seq=?", (proof["seq"],)).fetchone()
            cp = con.execute("SELECT * FROM checkpoints WHERE id=?", (proof["checkpoint_id"],)).fetchone()
        if row is None or cp is None or not 1 <= proof["seq"] <= cp["record_count"]:
            return False
        message = canonical_json({"root_hash": cp["root_hash"], "record_count": cp["record_count"],
                                  "previous_root": cp["previous_root"]})
        actual_leaf = hash_leaf(self._leaf_material(dict(row))).hex()
        return (self.crypto.verify(message, cp["signature"])
                and proof["root_hash"] == cp["root_hash"]
                and proof["leaf_hash"] == actual_leaf == row["leaf_hash"]
                and verify_inclusion(actual_leaf, proof["siblings"], cp["root_hash"]))

    def get_verified_alert(self, seq, proof):
        """Return the decrypted alert only when its stored record passes the proof."""
        if proof.get("seq") != seq or not self.verify_record_proof(proof):
            raise ValueError("alert rejected: integrity proof failed")
        with closing(self.connect()) as con, con:
            row = con.execute("SELECT * FROM alerts WHERE seq=?", (seq,)).fetchone()
        if row is None:
            raise ValueError("alert rejected: record is missing")
        aad = f"{row['seq']}|{row['alert_id']}|{row['created_at']}".encode()
        return json.loads(self.crypto.decrypt(row["nonce"], row["ciphertext"], aad))

    def verify_integrity(self):
        errors = []
        with closing(self.connect()) as con, con:
            rows = con.execute("SELECT * FROM alerts ORDER BY seq").fetchall()
            cps = con.execute("SELECT * FROM checkpoints ORDER BY id").fetchall()

        recomputed = []
        for r in rows:
            d = dict(r)
            expected = hash_leaf(self._leaf_material(d)).hex()
            recomputed.append(expected)
            if expected != r["leaf_hash"]:
                errors.append(f"leaf mismatch at seq={r['seq']}")

        prev = None
        for cp in cps:
            msg = canonical_json({
                "root_hash": cp["root_hash"],
                "record_count": cp["record_count"],
                "previous_root": cp["previous_root"]
            })
            if cp["previous_root"] != prev:
                errors.append(f"checkpoint chain mismatch at id={cp['id']}")
            if not self.crypto.verify(msg, cp["signature"]):
                errors.append(f"invalid signature at checkpoint id={cp['id']}")
            prev = cp["root_hash"]

        for cp in cps:
            count = cp["record_count"]
            if len(recomputed) >= count:
                if root_hex(recomputed[:count]) != cp["root_hash"]:
                    errors.append(f"Merkle root mismatch at checkpoint id={cp['id']}")
            else:
                errors.append(f"database rollback/deletion at checkpoint id={cp['id']}")
        if not cps and rows:
            errors.append("records exist but no checkpoint exists")

        return {"ok": not errors, "records": len(rows), "checkpoints": len(cps), "errors": errors}
