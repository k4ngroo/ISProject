from datetime import datetime, timezone
from .detector import severity_for

class NIDSService:
    def __init__(self, detector, store):
        self.detector = detector
        self.store = store
        self.total_flows = 0
        self.total_alerts = 0

    def process_flow(self, features):
        self.total_flows += 1
        label, confidence = self.detector.predict(features)
        if label.upper() in {"BENIGN", "NORMAL", "0"}:
            return None

        payload = {
            "created_at": datetime.now(timezone.utc).isoformat(),
            "src_ip": features.get("src_ip"),
            "dst_ip": features.get("dst_ip"),
            "src_port": features.get("src_port"),
            "dst_port": features.get("dst_port"),
            "protocol": features.get("protocol"),
            "label": label,
            "confidence": confidence,
            "severity": severity_for(label, confidence),
            "features": features,
        }
        self.total_alerts += 1
        return self.store.add_alert(payload)
