from .config import Settings
from .crypto import KeyManager
from .db import ForensicStore
from .detector import Detector
from .service import NIDSService
from .capture import CaptureEngine

class Runtime:
    def __init__(self):
        s = Settings().resolved()
        self.settings = s
        self.crypto = KeyManager(s.key_dir)
        self.store = ForensicStore(s.db_path, self.crypto, s.anchor_dir, s.checkpoint_interval)
        self.detector = Detector(s.model_path)
        self.service = NIDSService(self.detector, self.store)
        self.capture = CaptureEngine(self.service.process_flow, s.flow_idle_timeout, s.flow_max_age)
