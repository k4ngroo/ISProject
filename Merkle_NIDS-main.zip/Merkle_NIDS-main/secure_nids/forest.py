"""Small NumPy Random Forest for the demo's binary flow classifier."""
import numpy as np


class DemoRandomForest:
    def __init__(self, n_trees=21, max_depth=9, min_leaf=20, seed=42):
        self.n_trees = n_trees
        self.max_depth = max_depth
        self.min_leaf = min_leaf
        self.seed = seed
        self.trees = []
        self.classes_ = np.array(["BENIGN", "ATTACK"])

    def fit(self, x, y):
        x = np.asarray(x, dtype=np.float64)
        y = np.asarray(y) == "ATTACK"
        rng = np.random.default_rng(self.seed)
        self.trees = []
        for number in range(self.n_trees):
            indices = rng.integers(0, len(x), size=len(x))
            self.trees.append(self._grow(x[indices], y[indices], 0, rng))
            print(f"Trained tree {number + 1}/{self.n_trees}", flush=True)
        return self

    def _grow(self, x, y, depth, rng):
        probability = float((np.count_nonzero(y) + 1) / (len(y) + 2))
        if depth >= self.max_depth or len(y) < 2 * self.min_leaf or y.all() or not y.any():
            return (probability,)
        best = None
        for feature in rng.choice(x.shape[1], size=max(1, int(np.sqrt(x.shape[1]))), replace=False):
            values = x[:, feature]
            for threshold in np.unique(np.quantile(values, np.linspace(0.1, 0.9, 9))):
                left = values <= threshold
                count_left = int(left.sum())
                count_right = len(y) - count_left
                if min(count_left, count_right) < self.min_leaf:
                    continue
                positive_left = int(np.count_nonzero(y[left]))
                positive_right = int(np.count_nonzero(y)) - positive_left
                score = (2 * positive_left * (count_left - positive_left) / count_left
                         + 2 * positive_right * (count_right - positive_right) / count_right)
                if best is None or score < best[0]:
                    best = (score, int(feature), float(threshold), left)
        if best is None:
            return (probability,)
        _, feature, threshold, left = best
        return (feature, threshold, self._grow(x[left], y[left], depth + 1, rng),
                self._grow(x[~left], y[~left], depth + 1, rng))

    @staticmethod
    def _probability(row, node):
        while len(node) > 1:
            feature, threshold, left, right = node
            node = left if row[feature] <= threshold else right
        return node[0]

    def predict_proba(self, x):
        x = np.asarray(x, dtype=np.float64)
        attacks = np.array([sum(self._probability(row, tree) for tree in self.trees) / len(self.trees)
                            for row in x])
        return np.column_stack((1 - attacks, attacks))

    def predict(self, x):
        return np.where(self.predict_proba(x)[:, 1] >= 0.5, "ATTACK", "BENIGN")
