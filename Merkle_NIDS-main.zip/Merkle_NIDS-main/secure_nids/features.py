from dataclasses import dataclass, field
from statistics import mean
from scapy.layers.inet import IP, TCP, UDP
from .model_schema import MODEL_FEATURES

def pkt_tuple(pkt):
    if IP not in pkt:
        return None
    if TCP in pkt:
        return pkt[IP].src, pkt[IP].dst, int(pkt[TCP].sport), int(pkt[TCP].dport), "TCP"
    if UDP in pkt:
        return pkt[IP].src, pkt[IP].dst, int(pkt[UDP].sport), int(pkt[UDP].dport), "UDP"
    return None

@dataclass
class Flow:
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    protocol: str
    first_seen: float
    last_seen: float
    fwd_lens: list = field(default_factory=list)
    bwd_lens: list = field(default_factory=list)
    fwd_times: list = field(default_factory=list)
    bwd_times: list = field(default_factory=list)
    syn: int = 0
    ack: int = 0
    rst: int = 0
    psh: int = 0
    fin: int = 0

    def update(self, pkt):
        src, dst, sport, dport, _ = pkt_tuple(pkt)
        ts = float(pkt.time)
        self.last_seen = ts
        forward = src == self.src_ip and sport == self.src_port
        (self.fwd_lens if forward else self.bwd_lens).append(len(pkt))
        (self.fwd_times if forward else self.bwd_times).append(ts)

        if TCP in pkt:
            flags = int(pkt[TCP].flags)
            self.fin += bool(flags & 1)
            self.syn += bool(flags & 2)
            self.rst += bool(flags & 4)
            self.psh += bool(flags & 8)
            self.ack += bool(flags & 16)

    def _iat(self, ts):
        if len(ts) < 2:
            return 0.0
        return mean(b-a for a,b in zip(ts, ts[1:])) * 1_000_000

    def features(self):
        duration = max(self.last_seen - self.first_seen, 1e-6)
        total_packets = len(self.fwd_lens) + len(self.bwd_lens)
        total_bytes = sum(self.fwd_lens) + sum(self.bwd_lens)
        return {
            "flow_duration": duration * 1_000_000,
            "total_fwd_packets": len(self.fwd_lens),
            "total_bwd_packets": len(self.bwd_lens),
            "total_len_fwd_packets": sum(self.fwd_lens),
            "total_len_bwd_packets": sum(self.bwd_lens),
            "fwd_packet_len_mean": mean(self.fwd_lens) if self.fwd_lens else 0,
            "bwd_packet_len_mean": mean(self.bwd_lens) if self.bwd_lens else 0,
            "flow_bytes_s": total_bytes/duration,
            "flow_packets_s": total_packets/duration,
            "syn_flag_count": int(self.syn),
            "ack_flag_count": int(self.ack),
            "rst_flag_count": int(self.rst),
            "psh_flag_count": int(self.psh),
            "fin_flag_count": int(self.fin),
            "fwd_iat_mean": self._iat(self.fwd_times),
            "bwd_iat_mean": self._iat(self.bwd_times),
            "dst_port": self.dst_port,
            "src_ip": self.src_ip, "dst_ip": self.dst_ip,
            "src_port": self.src_port, "protocol": self.protocol,
        }

class FlowTable:
    def __init__(self, idle_timeout=2.0, max_age=5.0):
        self.idle_timeout = idle_timeout
        self.max_age = max_age
        self.flows = {}

    def _key(self, pkt):
        t = pkt_tuple(pkt)
        if not t:
            return None
        src, dst, sport, dport, proto = t
        a, b = sorted([(src, sport), (dst, dport)])
        return proto, a, b

    def consume(self, pkt):
        t = pkt_tuple(pkt)
        key = self._key(pkt)
        if not t or not key:
            return []
        now = float(pkt.time)
        done = self.expire(now)
        src, dst, sport, dport, proto = t
        if key not in self.flows:
            self.flows[key] = Flow(src, dst, sport, dport, proto, now, now)
        self.flows[key].update(pkt)
        return done

    def expire(self, now):
        done, remove = [], []
        for k, f in self.flows.items():
            if now-f.last_seen >= self.idle_timeout or now-f.first_seen >= self.max_age:
                done.append(f.features())
                remove.append(k)
        for k in remove:
            del self.flows[k]
        return done

    def flush(self):
        out = [f.features() for f in self.flows.values()]
        self.flows.clear()
        return out
