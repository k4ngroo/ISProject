from pathlib import Path
import joblib, pandas as pd
from .model_schema import MODEL_FEATURES

class Detector:
    def __init__(self, model_path):
        self.model_path = Path(model_path)
        self.model = joblib.load(self.model_path) if self.model_path.exists() else None

    def predict(self, f):
        if self.model is None:
            return "BENIGN", 0.50

        x = pd.DataFrame([[float(f.get(k, 0)) for k in MODEL_FEATURES]], columns=MODEL_FEATURES)
        label = str(self.model.predict(x)[0])
        confidence = float(self.model.predict_proba(x).max()) if hasattr(self.model, "predict_proba") else 1.0
        return label, confidence

def severity_for(label, confidence):
    if label.upper() in {"BENIGN", "NORMAL", "0"}:
        return "none"
    if confidence >= 0.95:
        return "critical"
    if confidence >= 0.80:
        return "high"
    return "medium"
