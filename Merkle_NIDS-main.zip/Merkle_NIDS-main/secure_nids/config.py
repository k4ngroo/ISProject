from dataclasses import dataclass
from pathlib import Path
import os

@dataclass(frozen=True)
class Settings:
    base_dir: Path = Path(os.getenv("NIDS_BASE_DIR", ".")).resolve()
    db_path: Path = Path(os.getenv("NIDS_DB_PATH", "data/forensics.db"))
    model_path: Path = Path(os.getenv("NIDS_MODEL_PATH", "data/nids_model.joblib"))
    key_dir: Path = Path(os.getenv("NIDS_KEY_DIR", "keys"))
    anchor_dir: Path = Path(os.getenv("NIDS_ANCHOR_DIR", "anchors"))
    checkpoint_interval: int = int(os.getenv("NIDS_CHECKPOINT_INTERVAL", "100"))
    flow_idle_timeout: float = float(os.getenv("NIDS_FLOW_IDLE_TIMEOUT", "2.0"))
    flow_max_age: float = float(os.getenv("NIDS_FLOW_MAX_AGE", "5.0"))

    def resolved(self):
        def p(x):
            return x if x.is_absolute() else self.base_dir / x
        return Settings(
            base_dir=self.base_dir,
            db_path=p(self.db_path),
            model_path=p(self.model_path),
            key_dir=p(self.key_dir),
            anchor_dir=p(self.anchor_dir),
            checkpoint_interval=max(1, self.checkpoint_interval),
            flow_idle_timeout=self.flow_idle_timeout,
            flow_max_age=self.flow_max_age,
        )
