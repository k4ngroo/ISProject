from scapy.all import AsyncSniffer, PcapReader
from .features import FlowTable
import time
from threading import Lock

class CaptureEngine:
    def __init__(self, on_flow, idle_timeout=2.0, max_age=5.0):
        self.on_flow = on_flow
        self.table = FlowTable(idle_timeout, max_age)
        self.sniffer = None
        self.lock = Lock()

    def _handle(self, pkt):
        with self.lock:
            completed = self.table.consume(pkt)
        for flow in completed:
            self.on_flow(flow)

    def start_live(self, iface=None):
        self.sniffer = AsyncSniffer(iface=iface, prn=self._handle, store=False, filter="tcp or udp")
        self.sniffer.start()

    def stop_live(self):
        if self.sniffer and self.sniffer.running:
            self.sniffer.stop()
        with self.lock:
            completed = self.table.flush()
        for flow in completed:
            self.on_flow(flow)

    def expire_live(self):
        with self.lock:
            completed = self.table.expire(time.time())
        for flow in completed:
            self.on_flow(flow)

    def analyze_pcap(self, path):
        packets = 0
        with PcapReader(str(path)) as reader:
            for pkt in reader:
                packets += 1
                self._handle(pkt)
        for flow in self.table.flush():
            self.on_flow(flow)
        return {"packets": packets}
