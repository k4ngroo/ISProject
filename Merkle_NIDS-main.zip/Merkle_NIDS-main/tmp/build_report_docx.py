from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Cm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'output' / 'Methodology_Results_Merkle_Expanded.docx'
OUT.parent.mkdir(exist_ok=True)
TMP = ROOT / 'tmp'
FONT = r'C:\Windows\Fonts\segoeui.ttf'

def draw_box(d, xy, label, fill='#E9F0F8', outline='#54708C', size=27):
    d.rounded_rectangle(xy, radius=14, fill=fill, outline=outline, width=3)
    font = ImageFont.truetype(FONT, size)
    lines = label.split('\n')
    heights = [d.textbbox((0, 0), line, font=font)[3] for line in lines]
    y = (xy[1] + xy[3] - sum(heights) - 8 * (len(lines)-1)) / 2
    for line, h in zip(lines, heights):
        box = d.textbbox((0, 0), line, font=font)
        d.text(((xy[0]+xy[2]-(box[2]-box[0]))/2, y), line, font=font, fill='#14263B')
        y += h + 8

def arrow(d, x1, y1, x2, y2):
    d.line((x1,y1,x2,y2), fill='#42596F', width=4)
    if x2 > x1: d.polygon([(x2,y2),(x2-13,y2-8),(x2-13,y2+8)], fill='#42596F')
    elif y2 > y1: d.polygon([(x2,y2),(x2-8,y2-13),(x2+8,y2-13)], fill='#42596F')

im = Image.new('RGB', (1500, 540), 'white'); d = ImageDraw.Draw(im)
draw_box(d,(25,35,315,130),'Labeled CICIDS2017\nflow CSVs')
draw_box(d,(420,35,705,130),'Eight features\nand labels')
draw_box(d,(810,35,1100,130),'Train 21 tree\nRandom Forest')
draw_box(d,(1190,35,1475,130),'Saved model')
for a,b in [(315,420),(705,810),(1100,1190)]: arrow(d,a,82,b-8,82)
draw_box(d,(25,235,300,345),'Live TCP UDP\npackets')
draw_box(d,(360,235,650,345),'Scapy flows\neight features')
draw_box(d,(720,235,1010,345),'BENIGN or ATTACK\nprediction')
draw_box(d,(1080,235,1475,345),'ATTACK alert\nAES GCM SQLite')
for a,b in [(300,360),(650,720),(1010,1080)]: arrow(d,a,290,b-8,290)
arrow(d,1333,130,1333,220); d.line((1333,220,860,220),fill='#42596F',width=4); arrow(d,860,220,860,235)
draw_box(d,(1080,420,1475,520),'Merkle root and\nRSA signed checkpoint')
arrow(d,1277,345,1277,408)
im.save(TMP/'architecture.png')

im = Image.new('RGB', (1500, 490), 'white'); d = ImageDraw.Draw(im)
nodes = [((55,365,295,455),'Stored alert 1\nleaf L1'),((400,365,640,455),'Stored alert 2\nleaf L2'),((865,365,1105,455),'Stored alert 3\nleaf L3'),((1210,365,1450,455),'Stored alert 4\nleaf L4'),
         ((215,210,480,300),'H(L1, L2)'),((1020,210,1285,300),'H(L3, L4)'),((605,40,895,135),'Merkle root')]
for xy,label in nodes: draw_box(d,xy,label,fill='#EDF4F8' if 'root' not in label else '#D9EDDF',size=26)
for x1,y1,x2,y2 in [(175,365,285,300),(520,365,410,300),(985,365,1090,300),(1330,365,1210,300),(348,210,690,135),(1152,210,810,135)]:
    d.line((x1,y1,x2,y2),fill='#42596F',width=4)
im.save(TMP/'merkle.png')

doc = Document(); sec=doc.sections[0]
sec.page_width=Cm(21); sec.page_height=Cm(29.7)
sec.top_margin=Cm(1.7); sec.bottom_margin=Cm(1.7); sec.left_margin=Cm(1.8); sec.right_margin=Cm(1.8)
styles=doc.styles
for name in ['Normal','Title','Heading 1','Heading 2','Caption']:
    st=styles[name]; st.font.name='Aptos'; st.font.color.rgb=None
    st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:ascii'),'Aptos')
    st._element.get_or_add_rPr().get_or_add_rFonts().set(qn('w:hAnsi'),'Aptos')
styles['Normal'].font.size=Pt(9.5); styles['Normal'].paragraph_format.space_after=Pt(4)
styles['Normal'].paragraph_format.line_spacing=1.06
styles['Title'].font.size=Pt(15); styles['Title'].font.bold=True
styles['Title'].paragraph_format.space_after=Pt(9)
styles['Heading 1'].font.size=Pt(11.5); styles['Heading 1'].font.bold=True
styles['Heading 1'].paragraph_format.space_before=Pt(9); styles['Heading 1'].paragraph_format.space_after=Pt(4)
styles['Heading 2'].font.size=Pt(10); styles['Heading 2'].font.bold=True
styles['Heading 2'].paragraph_format.space_before=Pt(6); styles['Heading 2'].paragraph_format.space_after=Pt(2)
styles['Caption'].font.size=Pt(8.5); styles['Caption'].font.italic=True
styles['Caption'].paragraph_format.space_after=Pt(6)

def para(text): doc.add_paragraph(text)
def heading(text, level=1): doc.add_heading(text, level=level)
def fig(path, caption):
    p=doc.add_paragraph(); p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after=Pt(1)
    p.add_run().add_picture(str(path), width=Cm(17.2))
    c=doc.add_paragraph(caption, style='Caption'); c.alignment=WD_ALIGN_PARAGRAPH.CENTER
def table(headers, rows, widths=None):
    t=doc.add_table(rows=1, cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER
    t.style='Table Grid'
    for i,h in enumerate(headers): t.rows[0].cells[i].text=h
    for row in rows:
        cells=t.add_row().cells
        for i,v in enumerate(row): cells[i].text=str(v)
    for rnum,row in enumerate(t.rows):
        for i,cell in enumerate(row.cells):
            cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            for p in cell.paragraphs:
                p.paragraph_format.space_after=Pt(0)
                for run in p.runs: run.font.size=Pt(8.5)
            if rnum==0:
                tcPr=cell._tc.get_or_add_tcPr(); shd=OxmlElement('w:shd'); shd.set(qn('w:fill'),'DCE8F1'); tcPr.append(shd)
                for p in cell.paragraphs:
                    for run in p.runs: run.bold=True
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths): row.cells[i].width=Cm(w)
    return t

doc.add_paragraph('Methodology and Results for a Secure Merkle NIDS Prototype', style='Title')
para('This draft describes the implemented detection and forensic pipeline and its measured demo results. It distinguishes the held-out CICIDS2017 classification results from unlabelled live traffic, and describes exactly what the Merkle proofs verify.')
heading('Methodology')
para('The system has two linked paths (Fig. 1). Offline training produces a binary flow classifier. During operation, live packets are assembled into flows, classified, and, when labeled ATTACK, recorded as encrypted forensic alerts. Merkle checkpoints then commit to the stored alert history.')
fig(TMP/'architecture.png','Fig. 1. Training, live detection, encrypted storage, and integrity pipeline.')
heading('Dataset and classifier',2)
para('The eight CICIDS2017 MachineLearningCSV files provide labeled flow statistics. The trainer reads CSVs in 50,000-row chunks, samples up to 300 records per original label per chunk, removes exact duplicate and invalid selected rows, and caps sampled classes before mapping BENIGN to BENIGN and all other labels to ATTACK. The final binary classes are balanced. An 80/20 random split yields 13,376 training flows and 3,344 held-out flows. The eight input features are flow duration, forward and backward packet counts, and SYN, ACK, RST, PSH, and FIN flag counts.')
para('A compact NumPy Random Forest contains 21 bootstrap-trained trees, maximum depth nine, and at least 20 observations per leaf. At each node it considers a random subset of features and candidate quantile thresholds. Tree attack scores are averaged; scores of at least 0.5 produce ATTACK. The NumPy implementation was used because the host application-control policy blocked a native scikit-learn DLL. The saved model is loaded when capture starts.')
heading('Live capture and encrypted alert storage',2)
para('Scapy captures IPv4 TCP and UDP packets on a selected interface. Bidirectional endpoint tuples form flows, which close after two seconds of inactivity, five seconds of age, or capture termination. Benign predictions are counted but not stored. An ATTACK prediction creates an alert containing a timestamp, endpoints, label, score, severity, and measured flow features.')
para('The alert payload is serialized as canonical JSON and encrypted with AES-256-GCM using a fresh 12-byte nonce and associated record identifiers. The AES key is wrapped using RSA-OAEP. SQLite stores ciphertext, nonce, a leaf hash, and searchable metadata. IP addresses, ports, labels, scores, and severity remain plaintext in the database; therefore encryption does not cover every sensitive field.')
heading('Merkle construction and record proofs',2)
para('Each alert becomes a leaf by hashing a canonical encoding of its stored sequence number, identifiers, metadata, nonce, and ciphertext. Distinct byte prefixes separate leaf hashing from parent-node hashing. Adjacent leaf hashes are paired and hashed repeatedly until one root remains (Fig. 2). When a level has an odd number of nodes, its final node is duplicated. Thus any change to a covered stored field changes its leaf and the root recomputed from that leaf.')
fig(TMP/'merkle.png','Fig. 2. Four-leaf Merkle tree; internal nodes hash their two child hashes.')
para('For a concrete five-record example, the first level contains H(L1,L2), H(L3,L4), and H(L5,L5). The third value is duplicated at the next level before the final root is formed. To prove inclusion of record 3, the proof supplies only L4, H(L1,L2), and the hash of the right-hand subtree. Starting at L3, the verifier combines these siblings in the specified left/right order and compares the result with the checkpoint root. This takes one hash operation per tree level, or O(log N), once a proof is available. In this implementation, proof construction first reads all checkpoint leaf hashes, so its current construction cost is O(N).')
para('More explicitly, a verifier computes P34 = H(L3,L4), then Q1234 = H(H(L1,L2),P34), and finally R = H(Q1234,Q55), where Q55 = H(H(L5,L5),H(L5,L5)). Left/right position matters: reversing a sibling changes the computed root. The signed root is therefore a compact commitment to record contents and order at the stated record count. The proof does not reveal the other alert payloads; only their hashes are needed for this check.')
para('A checkpoint signs the root, record count, and previous root with a 3072-bit RSA-PSS key; default checkpointing is every 100 alerts, and stopping capture creates one explicitly. Roots are cumulative over all alerts up to each checkpoint rather than separate disjoint epochs. A verified fetch checks the stored alert leaf, inclusion path, checkpoint signature, and AES-GCM authentication before returning the decrypted payload. The Merkle root is an integrity commitment, not a database address or an authorization credential.')
heading('Results and Discussion')
heading('Held-out classifier results',2)
para('Table 1 summarizes the 3,344-flow test set. Rows are actual classes and columns are predicted classes. Overall accuracy is 89.1%; ATTACK recall is 92.9% and precision is 86.4%. The 244 benign flows classified as attacks show a meaningful false-positive burden even within this balanced sample.')
table(['Actual class','Predicted BENIGN','Predicted ATTACK'],[['BENIGN','1,428','244'],['ATTACK','119','1,553']],[5.5,5.5,5.5])
doc.add_paragraph('Table 1. Confusion matrix for the held-out CICIDS2017 sample.',style='Caption')
table(['Class','Precision','Recall','F1 score'],[['BENIGN','0.923','0.854','0.887'],['ATTACK','0.864','0.929','0.895']],[5,4,4,4])
doc.add_paragraph('Table 2. Per-class metrics for the same held-out sample.',style='Caption')
heading('Live and integrity demonstrations',2)
para('An initial Windows loopback capture completed 61 flows and no alerts before the trained model was used. A later model-enabled capture completed 57 flows, generated 13 ATTACK alerts, and ended with a successful integrity check over 13 records and two checkpoints. The test traffic was ordinary localhost activity, without attack ground truth; these labels cannot be claimed as true intrusions. Several alert scores were close to the 0.5 decision threshold. A later database inspection showed 19 cumulative alerts and three checkpoints across runs, demonstrating persistence rather than a separate accuracy measurement.')
para('A normal storage demo inserted a manually labeled alert and verified its checkpoint. A five-record proof demo accepted a valid path for record 3 and rejected a forged leaf. In an isolated tamper demo, a verified alert was retrieved before one ciphertext byte was changed. After the change, leaf and root checks failed, the record proof returned false, and verified retrieval rejected the alert. These are controlled integrity demonstrations, not measured detection accuracy or an access-control test.')
heading('Interpretation and limits',2)
para('The random held-out split can place flows from related CICIDS2017 traffic scenarios on both sides of the split, despite exact-row deduplication. The live extractor also uses shorter flow timeouts than CICFlowMeter and may produce different feature distributions. These differences, together with unlabelled localhost traffic, prevent extrapolating the held-out metrics to live detection. The system has no user-authentication layer, TLS handshake analysis, measured insertion latency, proof-generation benchmark, or externally controlled checkpoint anchor. Local manifests and an unencrypted private-key file do not guarantee resistance to an attacker who controls the host and its keys.')

doc.save(OUT)
print(OUT)
