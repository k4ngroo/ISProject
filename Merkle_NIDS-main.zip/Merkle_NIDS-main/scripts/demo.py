from pathlib import Path
import sys, os, tempfile
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

with tempfile.TemporaryDirectory(prefix="nids-normal-") as directory:
    os.environ["NIDS_BASE_DIR"] = directory
    from secure_nids.runtime import Runtime
    rt = Runtime()
    alert = rt.store.add_alert({"src_ip": "10.0.0.15", "dst_ip": "10.0.0.1",
                                "src_port": 51000, "dst_port": 22, "protocol": "TCP",
                                "label": "PORT_SCAN", "confidence": 0.98, "severity": "critical"})
    rt.store.create_checkpoint()
    print("Alert:", alert)
    print("Integrity:", rt.store.verify_integrity())
