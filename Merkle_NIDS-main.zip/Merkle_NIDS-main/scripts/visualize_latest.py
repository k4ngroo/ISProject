"""Regenerate the latest Merkle tree from the current forensic database."""
import sqlite3
import sys
from contextlib import closing
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from secure_nids.config import Settings
from secure_nids.tree_visualizer import write_tree

settings = Settings().resolved()
with closing(sqlite3.connect(settings.db_path)) as con:
    checkpoint = con.execute("SELECT id, record_count, root_hash FROM checkpoints ORDER BY id DESC LIMIT 1").fetchone()
    if checkpoint is None:
        raise SystemExit("No checkpoint exists yet. Stop live capture to create one.")
    checkpoint_id, record_count, root_hash = checkpoint
    leaves = [row[0] for row in con.execute("SELECT leaf_hash FROM alerts ORDER BY seq LIMIT ?", (record_count,))]
if len(leaves) != record_count:
    raise SystemExit("Cannot draw tree: checkpoint records are missing.")
settings.anchor_dir.mkdir(parents=True, exist_ok=True)
path = settings.anchor_dir / "merkle_tree_latest.html"
write_tree(path, leaves, checkpoint_id, root_hash)
print(path.resolve())
