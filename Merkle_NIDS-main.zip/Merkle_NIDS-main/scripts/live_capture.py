from pathlib import Path
import argparse, sys, time, webbrowser
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

parser = argparse.ArgumentParser(description="Capture live TCP/UDP flows and print detections")
parser.add_argument("--iface", help="Scapy interface name; defaults to its selected interface")
parser.add_argument("--duration", type=float, help="stop after this many seconds")
parser.add_argument("--list-ifaces", action="store_true", help="show available capture interfaces")
parser.add_argument("--no-open-tree", action="store_true", help="save the Merkle visualizer without opening it")
args = parser.parse_args()
from scapy.all import conf, show_interfaces
if args.list_ifaces:
    show_interfaces()
    raise SystemExit(0)
if sys.platform == "win32" and not conf.use_pcap:
    parser.error("Npcap is required for live capture on Windows. Install Npcap, then rerun from an Administrator terminal.")
from secure_nids.runtime import Runtime
rt = Runtime()

def show_flow(features):
    result = rt.service.process_flow(features)
    route = f"{features['src_ip']}:{features['src_port']} -> {features['dst_ip']}:{features['dst_port']}"
    print(f"FLOW {route} {features['protocol']} packets={features['total_fwd_packets'] + features['total_bwd_packets']}", flush=True)
    if result:
        print(f"ALERT {result}", flush=True)

rt.capture.on_flow = show_flow
rt.capture.start_live(args.iface)
print(f"Capturing on {args.iface or 'Scapy default'}. Press Ctrl+C to stop.", flush=True)
started = time.monotonic()
try:
    while args.duration is None or time.monotonic() - started < args.duration:
        time.sleep(0.25)
        rt.capture.expire_live()
except KeyboardInterrupt:
    pass
finally:
    rt.capture.stop_live()
    rt.store.create_checkpoint()
    print(f"Flows={rt.service.total_flows} Alerts={rt.service.total_alerts}")
    print("Integrity:", rt.store.verify_integrity())
    tree_path = rt.settings.anchor_dir / "merkle_tree_latest.html"
    print("Merkle tree:", tree_path)
    if not args.no_open_tree:
        webbrowser.open(tree_path.resolve().as_uri())
