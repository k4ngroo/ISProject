"""Read alert metadata and signed checkpoint roots from the forensic SQLite file."""
import argparse
import json
import sqlite3
from contextlib import closing
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--db", type=Path, default=Path("data/forensics.db"))
parser.add_argument("--limit", type=int, default=10)
args = parser.parse_args()
if not args.db.is_file():
    parser.error(f"database not found: {args.db}")

with closing(sqlite3.connect(args.db.resolve().as_uri() + "?mode=ro", uri=True)) as con:
    con.row_factory = sqlite3.Row
    print("Alerts:", con.execute("SELECT COUNT(*) FROM alerts").fetchone()[0])
    print("Checkpoints:", con.execute("SELECT COUNT(*) FROM checkpoints").fetchone()[0])
    print("Recent alerts:")
    for row in con.execute("""SELECT seq, created_at, src_ip, dst_ip, src_port,
                              dst_port, protocol, label, confidence, severity,
                              length(ciphertext) AS encrypted_bytes
                              FROM alerts ORDER BY seq DESC LIMIT ?""", (max(0, args.limit),)):
        print(json.dumps(dict(row)))
    print("Checkpoint roots:")
    for row in con.execute("SELECT id, record_count, root_hash, previous_root FROM checkpoints ORDER BY id"):
        print(json.dumps(dict(row)))
