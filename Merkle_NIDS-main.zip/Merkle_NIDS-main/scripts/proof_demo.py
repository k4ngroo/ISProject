"""Show and verify a Merkle inclusion path against a signed checkpoint."""
import json
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
with tempfile.TemporaryDirectory(prefix="nids-proof-") as directory:
    os.environ["NIDS_BASE_DIR"] = directory
    from secure_nids.runtime import Runtime
    rt = Runtime()
    for number in range(1, 6):
        rt.store.add_alert({"label": f"DEMO_{number}", "src_ip": f"10.0.0.{number}",
                            "dst_ip": "10.0.0.100", "confidence": 0.9})
    rt.store.create_checkpoint()
    proof = rt.store.record_proof(3)
    print(json.dumps(proof, indent=2))
    print("Valid record 3 proof:", rt.store.verify_record_proof(proof))
    forged = {**proof, "leaf_hash": "00" * 32}
    print("Forged leaf proof:", rt.store.verify_record_proof(forged))
