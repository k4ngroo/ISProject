"""Train a demo Random Forest from the official CICIDS2017 flow CSV files."""
import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from secure_nids.model_schema import CIC_COLUMNS, MODEL_FEATURES
from secure_nids.forest import DemoRandomForest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_dir", type=Path, help="directory containing CICIDS2017 CSVs")
    parser.add_argument("--output", type=Path, default=Path("data/nids_model.joblib"))
    args = parser.parse_args()
    files = sorted(args.csv_dir.rglob("*.csv"))
    if not files:
        parser.error(f"no CSV files found under {args.csv_dir}")

    wanted = list(CIC_COLUMNS.values()) + ["Label"]
    pieces = []
    for path in files:
        print(f"Reading {path.name}", flush=True)
        for chunk in pd.read_csv(path, usecols=wanted, skipinitialspace=True,
                                 chunksize=50000, low_memory=False, encoding="latin1"):
            chunk.columns = chunk.columns.str.strip()
            chunk["Label"] = chunk["Label"].astype(str).str.strip()
            for _, group in chunk.groupby("Label", sort=False):
                pieces.append(group.sample(n=min(len(group), 300), random_state=42))

    data = pd.concat(pieces, ignore_index=True).drop_duplicates()
    data = pd.concat([
        group.sample(n=min(len(group), 10000 if label.upper() == "BENIGN" else 1500), random_state=42)
        for label, group in data.groupby("Label")
    ], ignore_index=True)
    data = data.rename(columns={value: key for key, value in CIC_COLUMNS.items()})
    for column in MODEL_FEATURES:
        data[column] = pd.to_numeric(data[column], errors="coerce")
    data = data.replace([np.inf, -np.inf], np.nan).dropna(subset=MODEL_FEATURES)
    labels = np.where(data["Label"].str.upper() == "BENIGN", "BENIGN", "ATTACK")
    benign = data.loc[labels == "BENIGN"]
    attack = data.loc[labels == "ATTACK"]
    if len(benign) < 2 or len(attack) < 2:
        raise ValueError("both BENIGN and attack rows are required")
    benign = benign.sample(n=min(len(benign), len(attack)), random_state=42)
    data = pd.concat([benign, attack], ignore_index=True)
    y = np.where(data["Label"].str.upper() == "BENIGN", "BENIGN", "ATTACK")
    rng = np.random.default_rng(42)
    train_indices, test_indices = [], []
    for label in ["BENIGN", "ATTACK"]:
        indices = rng.permutation(np.flatnonzero(y == label))
        split = max(1, int(len(indices) * 0.2))
        test_indices.extend(indices[:split])
        train_indices.extend(indices[split:])
    x_train = data.iloc[train_indices][MODEL_FEATURES]
    x_test = data.iloc[test_indices][MODEL_FEATURES]
    y_train, y_test = y[train_indices], y[test_indices]
    model = DemoRandomForest()
    model.fit(x_train, y_train)
    predicted = model.predict(x_test)
    matrix = [[int(np.count_nonzero((y_test == actual) & (predicted == guess)))
               for guess in ["BENIGN", "ATTACK"]] for actual in ["BENIGN", "ATTACK"]]
    report = {}
    for index, label in enumerate(["BENIGN", "ATTACK"]):
        tp = matrix[index][index]
        precision = tp / max(1, sum(row[index] for row in matrix))
        recall = tp / max(1, sum(matrix[index]))
        report[label] = {"precision": precision, "recall": recall,
                         "f1": 2 * precision * recall / max(1e-12, precision + recall),
                         "support": sum(matrix[index])}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, args.output)
    metadata = {"source_files": [str(path) for path in files], "features": MODEL_FEATURES,
                "training_rows": len(x_train), "test_rows": len(x_test),
                "classification_report": report,
                "confusion_matrix_labels": ["BENIGN", "ATTACK"], "confusion_matrix": matrix,
                "limitation": "random held-out flow split; live capture uses different flow timeout than CICFlowMeter"}
    args.output.with_suffix(".metrics.json").write_text(json.dumps(metadata, indent=2))
    print("Held-out metrics:", json.dumps(report, indent=2))
    print("Confusion matrix [BENIGN, ATTACK]:", matrix)
    print("Saved:", args.output)


if __name__ == "__main__":
    main()
