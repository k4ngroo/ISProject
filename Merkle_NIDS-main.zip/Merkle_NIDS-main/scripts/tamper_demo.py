from pathlib import Path
import sys, sqlite3, tempfile
from contextlib import closing
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

with tempfile.TemporaryDirectory(prefix="nids-tamper-") as directory:
    from secure_nids.crypto import KeyManager
    from secure_nids.db import ForensicStore
    root = Path(directory)
    db_path = root / "data" / "forensics.db"
    store = ForensicStore(db_path, KeyManager(root / "keys"), root / "anchors")
    alert = store.add_alert({"src_ip": "192.168.1.50", "dst_ip": "192.168.1.1",
                                "src_port": 40000, "dst_port": 443, "protocol": "TCP",
                                "label": "TEST_ATTACK", "confidence": 0.99, "severity": "high"})
    store.create_checkpoint()
    proof = store.record_proof(alert["seq"])
    print("BEFORE integrity:", store.verify_integrity())
    print("BEFORE proof:", store.verify_record_proof(proof))
    print("BEFORE fetched alert:", store.get_verified_alert(alert["seq"], proof))
    with closing(sqlite3.connect(db_path)) as con, con:
        blob = bytearray(con.execute("SELECT ciphertext FROM alerts WHERE seq=?", (alert["seq"],)).fetchone()[0])
        blob[0] ^= 1
        con.execute("UPDATE alerts SET ciphertext=? WHERE seq=?", (bytes(blob), alert["seq"]))
    print("AFTER integrity:", store.verify_integrity())
    print("AFTER proof:", store.verify_record_proof(proof))
    try:
        print("AFTER fetched alert:", store.get_verified_alert(alert["seq"], proof))
    except ValueError as exc:
        print("AFTER fetch rejected:", exc)
